package com.example.adminfordogtrainer

class Trainer {
}