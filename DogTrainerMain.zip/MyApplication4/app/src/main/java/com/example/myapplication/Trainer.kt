package com.example.myapplication

class Trainer(
    name: String,
    email: String,

    var specialization: String,
    var availability: String
) : User(name, email ,"") {
    fun viewScheduledSessions() {

    }

    fun provideFeedback() {

    }
}