package com.example.myapplication

class Notification(
    var message: String,
    var sender: User,
    var receiver: User,
    var timestamp: String
) {
    fun sendNotification() {

    }

    fun receiveNotification() {

    }
}