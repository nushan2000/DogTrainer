package com.example.myapplication

class TrainingProgram(
    var programName: String,
    var description: String,
    var duration: Int,
    var level: String
) {
    val sessions: MutableList<TrainingSession> = mutableListOf()

    fun viewDetails() {

    }

    fun viewSessions() {

    }

    fun enroll() {

    }
}